# -*- coding: utf-8 -*-
# try something like

import base64

import os

@auth.requires_login()
def index():
    return locals()

@auth.requires_login()
def admin():


    f= request.vars.foto64=request.vars.foto
    #strImg = base64.b64encode(f)
    response.vars="rosario"
    #ocultar el camppo en la Crud
    if 'view' in request.args:

        db.Persona.foto64.writable = False
        db.Persona.foto64.readable = False
    if 'edit' in request.args:

        db.Persona.foto64.writable = False
        db.Persona.foto64.readable = False
    if 'new' in request.args:
        #db.Persona.foto64.default = 'texto'
        db.Persona.foto64.writable = False
        db.Persona.foto64.readable = False

    grid = SQLFORM.smartgrid(db.Persona,
                            #fields=['foto64'],
                            field_id=None,
                            left=None,
                            headers={},
                            orderby=None,
                            groupby=None,
                            searchable=True,
                            sortable=True,
                            paginate=20,
                            deletable=True,
                            editable=True,
                            details=True,
                            selectable=None,
                            create=True,
                            csv=True,
                            links=None,
                            links_in_grid=True,

                            args=[],user_signature=False,
                            maxtextlengths={},
                            maxtextlength=20,
                            onvalidation=None,
                            oncreate=None,
                            onupdate=None,
                            ondelete=None,
                            sorter_icons=(XML('&#x2191;'),
                            XML('&#x2193;')),
                            ui = 'web2py',
                            showbuttontext=True,
                            _class="web2py_grid",
                            formname='web2py_grid',
                            search_widget='default',
                        )
    #leer las imagenes y guardar en base64 en la base de datos
    resultQueryPersona= db().select(db.Persona.id, db.Persona.foto,db.Persona.foto64)
    for linea in resultQueryPersona:
         if linea.foto:
            url = os.path.join(request.folder, "uploads/"+linea.foto)
            image = open(url, 'rb') #open binary file in read mode
            image_read = image.read()
            image_64_encode = base64.encodestring(image_read)
            db(db.Persona.id==linea.id).update(foto64=image_64_encode)


    return dict(grid=grid)

def personaJson():
    gente = db().select(db.Persona.ALL).as_list()
    return dict(gente=gente)

def download():
    return response.download(request, db)